"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { useState, useCallback } from "react"
import { Upload, FileText, CheckCircle, AlertCircle } from "lucide-react"

export function HeroSection() {
  const [dragActive, setDragActive] = useState(false)
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [verificationStatus, setVerificationStatus] = useState<"idle" | "verifying" | "verified" | "invalid">("idle")

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0]
      if (file.type === "application/pdf") {
        setUploadedFile(file)
        setVerificationStatus("idle")
      }
    }
  }, [])

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      if (file.type === "application/pdf") {
        setUploadedFile(file)
        setVerificationStatus("idle")
      }
    }
  }, [])

  const handleVerification = useCallback(() => {
    if (!uploadedFile) return

    setVerificationStatus("verifying")
    // Simulate verification process
    setTimeout(() => {
      setVerificationStatus(Math.random() > 0.3 ? "verified" : "invalid")
    }, 2000)
  }, [uploadedFile])

  return (
    <section className="relative py-20 sm:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-6xl">
          <div className="text-center">
            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-6xl lg:text-5xl text-balance">
              India's First Culturally Anchored Cryptographic Trust Layer
            </h1>
            <p className="mt-6 max-w-3xl mx-auto text-lg leading-8 text-muted-foreground text-pretty">
              {
                "Fake certificates cost India billions every year. We transform 3000-year-old Kolam art into next-generation security protocol, converting certificate data into mathematically unique, tamper-proof patterns tied to SHA-256 cryptographic hashes."
              }
            </p>
          </div>

          <div className="mt-16 flex flex-col items-center">
            <div className="relative">
              <div className="aspect-square w-80 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-2xl p-8 border border-border">
                <img
                  src="/traditional-indian-kolam-mandala-pattern-with-geom.jpg"
                  alt="Traditional Kolam pattern transformed into cryptographic security"
                  className="w-full h-full object-contain rounded-lg"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-medium">
                Cryptographically Secured
              </div>
            </div>

            <div className="mt-12 w-full max-w-md">
              <div
                className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  dragActive
                    ? "border-primary bg-primary/5"
                    : uploadedFile
                      ? "border-green-500 bg-green-50 dark:bg-green-950/20"
                      : "border-border hover:border-primary/50"
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <input
                  type="file"
                  accept=".pdf"
                  onChange={handleFileInput}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />

                {uploadedFile ? (
                  <div className="flex flex-col items-center space-y-2">
                    <FileText className="h-8 w-8 text-green-600" />
                    <p className="text-sm font-medium text-green-700 dark:text-green-400">{uploadedFile.name}</p>
                    <p className="text-xs text-muted-foreground">Ready for verification</p>
                  </div>
                ) : (
                  <div className="flex flex-col items-center space-y-2">
                    <Upload className="h-8 w-8 text-muted-foreground" />
                    <p className="text-sm font-medium">Drop your PDF certificate here</p>
                    <p className="text-xs text-muted-foreground">or click to browse</p>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-6">
              <Button
                size="lg"
                className="px-12 py-4 text-lg font-semibold"
                onClick={handleVerification}
                disabled={!uploadedFile || verificationStatus === "verifying"}
              >
                {verificationStatus === "verifying" ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Verifying...
                  </>
                ) : (
                  "Verify Your Certificate"
                )}
              </Button>
            </div>

            {verificationStatus === "verified" && (
              <div className="mt-4 flex items-center space-x-2 text-green-600">
                <CheckCircle className="h-5 w-5" />
                <span className="font-medium">Certificate Verified Successfully</span>
              </div>
            )}

            {verificationStatus === "invalid" && (
              <div className="mt-4 flex items-center space-x-2 text-red-600">
                <AlertCircle className="h-5 w-5" />
                <span className="font-medium">Certificate Could Not Be Verified</span>
              </div>
            )}
          </div>

          {/* Existing code */}
          <div className="mt-20 grid grid-cols-1 gap-8 sm:grid-cols-3">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">400M+</div>
              <div className="text-sm text-muted-foreground">Indians in low connectivity areas supported</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">Millions</div>
              <div className="text-sm text-muted-foreground">Fake certificates tackled annually</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">Offline</div>
              <div className="text-sm text-muted-foreground">Multilingual verification</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
